# Instructions

* Create a basic HTML page with your own information that looks similar to the design shown on screen.

  ![Make it look like this](demo.png)
